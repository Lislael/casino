const axios = require('axios');
const { env, assertBravopayConfigured } = require('../config/env');
const { money } = require('../utils/money');
const AppError = require('../utils/AppError');

function normalizedStatus(status) {
  const value = String(status || '').toUpperCase();
  if (value === 'PAID') return 'COMPLETED';
  if (['FAILED', 'REJECTED', 'EXPIRED'].includes(value)) return 'FAILED';
  if (['PENDING', 'PROCESSING'].includes(value)) return 'PENDING';
  const error = new AppError('Resposta da BravoPay nao reconhecida. Aguarde a conciliacao do pagamento.', 502, 'BRAVOPAY_INVALID_STATUS');
  error.isAmbiguous = true;
  throw error;
}

function cents(amount) {
  const result = money(amount).times(100).toNumber();
  if (!Number.isSafeInteger(result) || result <= 0) throw new AppError('Valor invalido.', 422, 'INVALID_AMOUNT');
  return result;
}

function invalidResponse() {
  const error = new AppError('Resposta incompleta da BravoPay. Aguarde a conciliacao antes de tentar novamente.', 502, 'BRAVOPAY_INVALID_RESPONSE');
  error.isAmbiguous = true;
  return error;
}

async function request(method, path, data, idempotencyKey, params, apiKey = env.bravopay.apiKey) {
  assertBravopayConfigured();
  try {
    const response = await axios.request({
      method, url: `${env.bravopay.baseUrl}${path}`, data, params,
      timeout: env.bravopay.timeoutMs,
      maxRedirects: 0,
      // Os proxies da VeoPag nao sao usados pela BravoPay.
      proxy: false,
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}),
      },
    });
    return response.data;
  } catch (cause) {
    // Timeout, falha de rede e 5xx nao comprovam que o PSP rejeitou o saque.
    // Nao reenviar nem devolver o saldo automaticamente nesses casos.
    const status = cause.response?.status;
    const ambiguous = !status || status >= 500 || status === 408 || (status >= 300 && status < 400);
    const error = new AppError(
      ambiguous
        ? 'A gateway nao confirmou a resposta. Aguarde a conciliacao antes de tentar novamente.'
        : 'A BravoPay recusou a solicitacao. Verifique os dados ou tente novamente mais tarde.',
      status === 429 ? 429 : 502,
      `BRAVOPAY_${String(cause.response?.data?.error?.code || 'REQUEST_FAILED').toUpperCase()}`,
    );
    error.isAmbiguous = ambiguous;
    error.providerStatus = status || null;
    throw error;
  }
}

async function createDeposit(payload) {
  const amountCents = cents(payload.amount);
  const response = await request('POST', '/transactions', {
    amount_cents: amountCents,
    method: 'pix',
    customer: {
      name: payload.payer.name,
      email: payload.payer.email,
      cpf: payload.payer.document,
      ...(payload.payer.phone ? { phone: payload.payer.phone } : {}),
    },
    description: `Deposito ${payload.external_id}`,
    external_reference: payload.external_id,
    expires_in: 3600,
  }, `bravopay:deposit:${payload.external_id}`);
  if (!response?.id || response.amount_cents !== amountCents || !response.pix?.copy_paste
      || !Number.isFinite(Date.parse(response.pix?.expires_at))) throw invalidResponse();
  return {
    transactionId: String(response.id),
    external_id: payload.external_id,
    status: normalizedStatus(response.status),
    amount: amountCents / 100,
    qrcode: response.pix.copy_paste,
    paymentCode: response.pix.copy_paste,
    expiresAt: new Date(response.pix.expires_at).toISOString(),
  };
}

async function createWithdrawal(payload) {
  const amountCents = cents(payload.amount);
  if (amountCents < 3000) throw new AppError('O saque minimo da BravoPay e de R$ 30,00.', 422, 'WITHDRAWAL_MINIMUM_NOT_MET');
  const response = await request('POST', '/withdrawals', {
    amount_cents: amountCents,
    method: 'pix',
    pix_key: payload.pix_key,
    pix_key_type: payload.key_type.toLowerCase(),
  }, `bravopay:withdrawal:${payload.external_id}`, undefined, env.bravopay.withdrawalApiKey);
  if (!response?.id || response.amount_cents !== amountCents) throw invalidResponse();
  return {
    transaction_id: String(response.id),
    status: normalizedStatus(response.status),
    amount: amountCents / 100,
    fee_cents: response.fee_cents,
    net_cents: response.net_cents,
  };
}

function getWithdrawal(id) {
  return request('GET', `/withdrawals/${encodeURIComponent(id)}`, undefined, undefined, undefined, env.bravopay.withdrawalApiKey);
}

async function accountInfo() {
  const [account, balance] = await Promise.all([request('GET', '/me'), request('GET', '/balance')]);
  return { provider: 'bravopay', account, balance };
}

module.exports = { createDeposit, createWithdrawal, getWithdrawal, accountInfo, normalizedStatus, cents };
