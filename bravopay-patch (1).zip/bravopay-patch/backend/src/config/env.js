const path = require('node:path');
const dotenv = require('dotenv');
const proxyConfig = require('./proxyConfig');

dotenv.config({ path: path.resolve(process.cwd(), '.env'), quiet: true });

function numberFromEnv(name, fallback) {
  const value = process.env[name];
  if (value === undefined || value === '') return fallback;

  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    throw new Error(`${name} precisa ser numerico.`);
  }

  return parsed;
}

function booleanFromEnv(name, fallback) {
  const value = process.env[name];
  if (value === undefined || value === '') return fallback;
  return value.toLowerCase() === 'true';
}

function csvFromEnv(name, fallback = []) {
  const value = process.env[name];
  if (!value) return fallback;
  return value.split(',').map((item) => item.trim()).filter(Boolean);
}

const env = Object.freeze({
  nodeEnv: process.env.NODE_ENV || 'development',
  port: numberFromEnv('PORT', 4000),
  publicBackendUrl: (process.env.PUBLIC_BACKEND_URL || '').replace(/\/$/, ''),
  corsOrigins: csvFromEnv('CORS_ORIGINS', [
    'http://localhost:3000',
    'http://localhost:5173',
  ]),
  database: {
    url: process.env.DATABASE_URL || '',
    ssl: booleanFromEnv('DATABASE_SSL', true),
    poolMax: numberFromEnv('DATABASE_POOL_MAX', 5),
    connectionTimeoutMs: numberFromEnv('DATABASE_CONNECTION_TIMEOUT_MS', 8000),
    queryTimeoutMs: numberFromEnv('DATABASE_QUERY_TIMEOUT_MS', 12000),
    statementTimeoutMs: numberFromEnv('DATABASE_STATEMENT_TIMEOUT_MS', 10000),
  },
  originProtection: {
    enabled: booleanFromEnv('ORIGIN_PROTECTION_ENABLED', false),
    headerName: (process.env.ORIGIN_VERIFY_HEADER || 'x-origin-verify').toLowerCase(),
    secret: process.env.ORIGIN_VERIFY_SECRET || '',
  },
  supabase: {
    url: process.env.SUPABASE_URL || '',
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY || '',
  },
  jwt: {
    secret: process.env.JWT_SECRET || '',
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  },
  admin: {
    emails: csvFromEnv('ADMIN_EMAILS').map((email) => email.toLowerCase()),
    panelSecret: process.env.ADMIN_PANEL_SECRET || '',
  },
  pushcut: {
    encryptionKey: process.env.PUSHCUT_ENCRYPTION_KEY || '',
    timeoutMs: numberFromEnv('PUSHCUT_TIMEOUT_MS', 5000),
  },
  managerWebPush: {
    publicKey: process.env.MANAGER_WEB_PUSH_PUBLIC_KEY || '',
    privateKey: process.env.MANAGER_WEB_PUSH_PRIVATE_KEY || '',
    subject: process.env.MANAGER_WEB_PUSH_SUBJECT || '',
  },
  notifications: {
    iconUrl: process.env.NOTIFICATION_ICON_URL || '',
  },
  maxApi: {
    baseUrl: process.env.MAX_API_BASE_URL || 'https://maxapigames.com/api/v2',
    agentCode: process.env.MAX_AGENT_CODE || '',
    agentToken: process.env.MAX_AGENT_TOKEN || '',
    agentSecret: process.env.MAX_AGENT_SECRET || '',
    webhookUrl: process.env.MAX_WEBHOOK_URL || '',
    timeoutMs: numberFromEnv('MAX_API_TIMEOUT_MS', 10000),
  },
  paymentProvider: (process.env.PAYMENT_PROVIDER || 'velopag').trim().toLowerCase(),
  bravopay: {
    baseUrl: (process.env.BRAVOPAY_API_URL || 'https://bravopay.club/api/v1').replace(/\/$/, ''),
    apiKey: process.env.BRAVOPAY_API_KEY || '',
    // Chave do tipo "Saque" (Dashboard > API Keys). A chave de cobrancas recebe 403 withdrawal_key_required.
    withdrawalApiKey: process.env.BRAVOPAY_WITHDRAWAL_API_KEY || process.env.BRAVOPAY_API_KEY || '',
    webhookSecret: process.env.BRAVOPAY_WEBHOOK_SECRET || '',
    timeoutMs: numberFromEnv('BRAVOPAY_API_TIMEOUT_MS', 15000),
  },
  velopag: {
    baseUrl: (process.env.VELOPAG_API_URL || 'https://api.veopag.com').replace(/\/$/, ''),
    clientId: process.env.VELOPAG_CLIENT_ID || '',
    clientSecret: process.env.VELOPAG_CLIENT_SECRET || '',
    webhookSignature: process.env.VELOPAG_WEBHOOK_SIGNATURE || '',
    depositCallbackUrl: process.env.VELOPAG_DEPOSIT_CALLBACK_URL || '',
    withdrawalCallbackUrl: process.env.VELOPAG_WITHDRAWAL_CALLBACK_URL || '',
    timeoutMs: numberFromEnv('VELOPAG_API_TIMEOUT_MS', 15000),
    proxy: {
      ...proxyConfig('VELOPAG_PROXY', numberFromEnv),
      fallback: proxyConfig('VELOPAG_PROXY_FALLBACK', numberFromEnv),
      third: proxyConfig('VELOPAG_PROXY_THIRD', numberFromEnv),
    },
  },
});

function validateCoreEnvironment() {
  if (!['velopag', 'bravopay'].includes(env.paymentProvider)) {
    throw new Error('PAYMENT_PROVIDER precisa ser velopag ou bravopay.');
  }
  const missing = [];
  if (!env.database.url) missing.push('DATABASE_URL');
  if (!env.jwt.secret) missing.push('JWT_SECRET');

  if (missing.length > 0) {
    throw new Error(`Variaveis obrigatorias ausentes: ${missing.join(', ')}`);
  }

  if (env.jwt.secret.length < 32) {
    throw new Error('JWT_SECRET precisa ter pelo menos 32 caracteres.');
  }

  if (env.originProtection.enabled && env.originProtection.secret.length < 32) {
    throw new Error('ORIGIN_VERIFY_SECRET precisa ter pelo menos 32 caracteres quando a protecao de origem estiver ativa.');
  }

  if (env.admin.emails.length > 0 && env.admin.panelSecret.length < 32) {
    throw new Error('ADMIN_PANEL_SECRET precisa ter pelo menos 32 caracteres quando ADMIN_EMAILS estiver configurado.');
  }
}

function assertMaxConfigured() {
  const missing = [];
  if (!env.maxApi.agentCode) missing.push('MAX_AGENT_CODE');
  if (!env.maxApi.agentToken) missing.push('MAX_AGENT_TOKEN');
  if (!env.maxApi.agentSecret) missing.push('MAX_AGENT_SECRET');

  if (missing.length > 0) {
    const error = new Error(`MAX API nao configurada: ${missing.join(', ')}`);
    error.code = 'MAX_NOT_CONFIGURED';
    error.statusCode = 503;
    throw error;
  }
}

function assertVelopagConfigured() {
  const missing = [];
  if (!env.velopag.clientId) missing.push('VELOPAG_CLIENT_ID');
  if (!env.velopag.clientSecret) missing.push('VELOPAG_CLIENT_SECRET');

  if (missing.length > 0) {
    const error = new Error(`VeloPag nao configurada: ${missing.join(', ')}`);
    error.code = 'VELOPAG_NOT_CONFIGURED';
    error.statusCode = 503;
    throw error;
  }
}

function maxWebhookUrl() {
  if (env.maxApi.webhookUrl) return env.maxApi.webhookUrl;
  if (!env.publicBackendUrl) return '';
  return `${env.publicBackendUrl}/api/webhooks/max-games`;
}

function velopagCallbackUrl(type) {
  if (type === 'deposit' && env.velopag.depositCallbackUrl) {
    return env.velopag.depositCallbackUrl;
  }

  if (type === 'withdrawal' && env.velopag.withdrawalCallbackUrl) {
    return env.velopag.withdrawalCallbackUrl;
  }

  if (!env.publicBackendUrl) return '';
  return `${env.publicBackendUrl}/api/webhooks/velopag/${type}`;
}

function assertBravopayConfigured() {
  if (!env.bravopay.apiKey || !env.bravopay.webhookSecret) {
    const error = new Error('Configure BRAVOPAY_API_KEY e BRAVOPAY_WEBHOOK_SECRET antes de ativar BravoPay.');
    error.statusCode = 503;
    error.code = 'BRAVOPAY_NOT_CONFIGURED';
    throw error;
  }
  const url = new URL(env.bravopay.baseUrl);
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
    throw new Error('BRAVOPAY_API_URL precisa ser uma URL HTTPS sem credenciais ou parametros.');
  }
}

module.exports = {
  env,
  validateCoreEnvironment,
  assertMaxConfigured,
  assertVelopagConfigured,
  assertBravopayConfigured,
  maxWebhookUrl,
  velopagCallbackUrl,
};
